# place holder for enhancing exceptions
# not used heavily

class myerror(Exception):
    pass

